require('dotenv').config();
const AWS = require('aws-sdk');
const axios = require('axios');

// Configure AWS SDK
const s3 = new AWS.S3({ region: 'us-east-1' }); // Update region if needed; I will check with the final account during the deployment.

const BUCKET_NAME = 'is215-image-labeling'; //S3 Bucket Name

async function generateArticleFromJson(outputKey) {
    try {

        const JSON_FILE_KEY = outputKey; // Added to declare JSON FILE KEY based on the parameter passed by index.js

        // Retrieval of JSON from S3 for OpenAI endpoint query later.
        const s3Data = await s3.getObject({
            Bucket: BUCKET_NAME,
            Key: JSON_FILE_KEY
        }).promise();

        const jsonString = s3Data.Body.toString('utf-8');
        const jsonContent = JSON.parse(jsonString);

        //Extract label names from the JSON.
        const labels = jsonContent.Labels.map(label => label.Name).join(', ');

        //Build prompt or query using the extracted label
        const prompt = `Write a fictional news article based on the following image labels: ${labels}. Make it sound like a creative, short feature story. You are a creative journalist popular in making articles trending today.`;

        //Call OpenAI endpoint
        const response = await axios.post(
            'https://is215-openai.upou.io/v1/chat/completions',
            {
                model: 'gpt-3.5-turbo',
                messages: [{ role: 'user', content: prompt }]
            },
            {
                headers: {
                    Authorization: `Bearer rebadavia-d8f1HS8rob`,
                    'Content-Type': 'application/json'
                }
            }
        );

        const article = response.data.choices[0].message.content;

        //Output the article on console too.
        console.log('\n Fictional Article:\n');
        console.log(article);

        //Adding Article to push back as JSON in S3
        const articleKey = `articles/${outputKey.split('/').pop().split('_')[0]}_article.json`;

        await s3.putObject({
            Bucket: BUCKET_NAME,
            Key: articleKey,
            Body: JSON.stringify({ article }, null, 2),
            ContentType: 'application/json'
        }).promise();

        //// Generate article filename
        //const articleName = key.split('/').pop().split('.')[0];
        //const articleKey = `Articles/${articleName}_Article.json`;

        //// Upload the JSON file to S3
        //await s3.putObject({
        //    Bucket: BUCKET_NAME,
        //    Key: articleKey,
        //    Body: JSON.stringify(labels, null, 1),
        //    ContentType: 'application/json'
        //}).promise();

    } catch (err) {
        console.error('Error:', err.message || err);
        return 'Error generating article.';
    }
}

// For local testing
if (require.main === module) {
    const testKey = 'uploads/cat.jpg'; // simulate uploaded file path
    generateArticleFromJson(testKey).then(console.log);
}

module.exports = generateArticleFromJson;